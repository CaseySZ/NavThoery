//
//  EOCTextLabel.m
//  CoreTextPreClass
//
//  Created by EOC on 2017/4/18.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCTextLabel.h"
#import <CoreText/CoreText.h>

@implementation EOCTextLabel{
    
    
}

- (void)drawRect:(CGRect)rect {
    
    // 1 准备数据 NSMutableAttributedString
    NSMutableDictionary *infoDict = [NSMutableDictionary dictionary];
    [infoDict setObject:[UIFont systemFontOfSize:14] forKey:NSFontAttributeName];
    NSMutableAttributedString *atttibuteString = [[NSMutableAttributedString alloc] initWithString:@"12345678" attributes:infoDict];
    CTFramesetterRef setterRef = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)atttibuteString);
    CGMutablePathRef pathRef = CGPathCreateMutable();
    CGPathAddRect(pathRef, NULL, CGRectMake(0, 0, 200, 200));
    CTFrameRef frameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(0, 0), pathRef, NULL);
    
    NSArray *lineRefAry = (__bridge NSArray*)CTFrameGetLines(frameRef);
    NSInteger lineCounts = lineRefAry.count;
    CGPoint lineOrigins[lineCounts];// memset
    CTFrameGetLineOrigins(frameRef, CFRangeMake(0, 0), lineOrigins);
    
    CTLineRef lineRef = (__bridge CTLineRef)lineRefAry[0];
    CFArrayRef runs = CTLineGetGlyphRuns(lineRef);
    
    
    // 开始上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0, self.bounds.size.height);
    CGContextScaleCTM(context, 1, -1);
    
    for (NSUInteger r = 0, rMax = CFArrayGetCount(runs); r < rMax; r++) {
        CTRunRef run = CFArrayGetValueAtIndex(runs, r);
        NSRange runRange = NSMakeRange(CTRunGetStringRange(run).location, CTRunGetStringRange(run).length);
        CFDictionaryRef runAttrs = CTRunGetAttributes(run);
        
        CTFontRef runFont = CFDictionaryGetValue(runAttrs, kCTFontAttributeName);
        NSUInteger glyphCount = CTRunGetGlyphCount(run);
        
        CGGlyph glyphs[glyphCount];
        CGPoint glyphPositions[glyphCount];
        CTRunGetGlyphs(run, CFRangeMake(0, 0), glyphs);
        CTRunGetPositions(run, CFRangeMake(0, 0), glyphPositions);
        
        
        CFIndex runStrIdx[glyphCount + 1];
        CTRunGetStringIndices(run, CFRangeMake(0, 0), runStrIdx);
        CFRange runStrRange = CTRunGetStringRange(run);
        runStrIdx[glyphCount] = runStrRange.location + runStrRange.length;
        CGSize glyphAdvances[glyphCount];
        CTRunGetAdvances(run, CFRangeMake(0, 0), glyphAdvances);
        
        CGPoint zeroPoint = CGPointZero;
        
        NSUInteger rangeMax = runRange.location + runRange.length;
        
        for (NSUInteger g = runRange.location; g < rangeMax; g++) {
            CGContextSaveGState(context); {
                
                CGContextSetTextMatrix(context, CGAffineTransformIdentity);
                CGContextRotateCTM(context, -M_PI_2);
                CGFloat glyplhX = -620 + glyphPositions[g].x;
                CGFloat glyplhY = 347 + glyphPositions[g].y;
                CGContextSetTextPosition(context,glyplhX, glyplhY);
                
                CGFontRef cgFont = CTFontCopyGraphicsFont(runFont, NULL);
                CGContextSetFont(context, cgFont);
                CGContextSetFontSize(context, CTFontGetSize(runFont));
                CGContextShowGlyphsAtPositions(context, glyphs + g, &zeroPoint, 1);
                CGFontRelease(cgFont);
                
            }
            CGContextRestoreGState(context);
        }
    }
}

@end
