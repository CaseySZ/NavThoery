//
//  main.m
//  CoreTextPreClass
//
//  Created by EOC on 2017/4/18.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
